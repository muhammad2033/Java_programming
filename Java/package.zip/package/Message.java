package ahmad.khan.core;  
class Message{  
  public static void main(String args[]){  
   System.out.println("Hello subpackage");  
  }  
}  