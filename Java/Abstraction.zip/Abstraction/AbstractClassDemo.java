class AbstractClassDemo {

    public static void main(String[] args) {

        Contractor contractor = new Contractor("contractor", 10, 10);
        FullTimeEmployee fullTimeEmployee = new FullTimeEmployee("full time employee", 8);
        System.out.println(contractor.calculateSalary());
        System.out.println(fullTimeEmployee.calculateSalary());
    }
}