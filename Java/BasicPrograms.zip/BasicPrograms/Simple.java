class Simple{
	public static void main(String[] abc){
	System.out.print("Hello Java");
	System.out.print("Hello World");
	}
}